# MMG-Test
This is a program simulating a request response cycle in openRTB protocol
between two actors implemented with akka.

To run:
  1. download
  2. unzip
  3. cd to root directory
  4. sbt
  5. run

Java 8 & sbt need to be already installed