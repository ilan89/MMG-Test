package com.mmg.test

//import statements
import akka.actor._
import spray.json._

import scala.io.Source
import com.mmg.test.BidRequestJson._
import com.mmg.test.BidResponseJson._
import com.mmg.test.Advertiser.{ReceiveBidRequest, ReceiveWinningNotice}

//Define Publisher case classes and props
object PublisherActor {
  def props(currRequestID:String, currImpSeq:Seq[Impression], advertiserActor: ActorRef): Props = Props(new PublisherActor("", Seq.empty[Impression],advertiserActor))
  final case class CreateAndSendBidRequest(fileName: String)
  final case class ReceiveBidResponse(bidResponseObj: BidResponse)
  final case class ReceiveAdMarkup(adMarkup:String,impID:String)
}

/*
* The Publisher class simulates the server in the openRTB protocol
* This class defines all the logic of the publisher */
class PublisherActor(var currRequestID:String,
                     var currImpSeq:Seq[Impression],
                     advertiserActor: ActorRef) extends Actor {
  import PublisherActor._
  import BidRequestJsonProtocol._
  import BidResponseJsonProtocol._

  /*
  this function iterates through the seats & bids to find the winning bid
   for each specific impression sent in the bidResquest
  * */
  private def pickWinningBid(seatBidSeq : Seq[SeatBid], impId:String ): (String, Bid) = {

    //initialize variables for storing the winning seat & bid
    var winningPrice:Float = 0
    var winningSeat = ""
    var winningBid = new Bid("","","",0)

    /*
    * iterate through the seats and find the bid made for the impression
    * compare the winning bid till now with the bid in loop by the price offered
    * if the bid in loop has a higher offer then update the winning bid
    * */
    seatBidSeq.foreach( seat => {
      seat.bid.foreach( bid => {
        if(impId==bid.impid){
          if(winningPrice<bid.price){
            winningPrice = bid.price
            winningSeat = seat.seat
            winningBid = bid
          }
        }
      })
    })

    //return the winning seat id (String) and the winning Bid (object)
    return (winningSeat,winningBid)
  }

  //The logic of the actor messages is here
  def receive = {
    /*
    * This case starts the RTB cycle
    * Get a file name containing the bid request in json format
    * imports the file and transform the bid request into an object
    * sends the request to the advertiser*/
    case CreateAndSendBidRequest(fileName) => {
      val bidRequestStr = Source.fromFile(fileName).getLines.mkString
      val bidRequestJSON = bidRequestStr.parseJson
      val bidRequestObj = bidRequestJSON.convertTo[BidRequest]
      println(self.path.name + " is reading the id: " + bidRequestObj.id)
      println(self.path.name + " is reading the user agent: " + bidRequestObj.device.ua)

      currRequestID = bidRequestObj.id
      currImpSeq = bidRequestObj.imp

      advertiserActor ! ReceiveBidRequest(bidRequestObj)
    }


    case ReceiveBidResponse(bidResponseObj) => {
      //parse the bidResponse to json format and print
      val bidResponseJson = bidResponseObj.toJson.prettyPrint
      println("I'm "+self.path.name +" and this is the bidResponse that "+sender().path.name+ " sent me:")
      println(bidResponseJson)

      //empty placeholder for the winning bids per impression
      //Map[Impression -> (seatID,Bid)]
      var myMap: Map[Impression, (String, Bid)] = Map()

      //for each impression, find the winning bid and add it to the map
      currImpSeq.foreach(imp => {
        myMap += (imp -> pickWinningBid( bidResponseObj.seatBid, imp.id)) // add the bid with the highest price. per impression
      })

      //Send the winning notice to the advertiser
      //the object being send is (impression:Impression,(seatID :String, bid : Bid)
      myMap.foreach(winner => {
        sender() ! ReceiveWinningNotice(winner)
      })
    }

    //This case prints the winning bid's adMarkup for the specific impression
    case ReceiveAdMarkup(adMarkup, impID) => {
      println("I am " + self.path.name+ " and the adMarkup for the impression " +impID + " is: " + adMarkup)
    }
  }


}


