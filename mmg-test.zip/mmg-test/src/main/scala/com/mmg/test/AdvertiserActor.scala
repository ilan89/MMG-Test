package com.mmg.test

//import statements
import akka.actor._

import com.mmg.test.BidRequestJson._
import com.mmg.test.BidResponseJson.{Bid, _}

//Define Advertiser case classes
object Advertiser {
  final case class ReceiveBidRequest(bidRequestObj: BidRequest)
  final case class ReceiveWinningNotice(winNote: (Impression, (String, Bid)))
}
/*
* The AdvertiserActor class simulates the client in the openRTB protocol
* This class defines all the logic of the advertiser */
class AdvertiserActor() extends Actor {
  import PublisherActor._
  import Advertiser._

  //This function generates Bid Responses
  //Gets a BidRequest object and returns a BidResponse object with 5 seats
  private def createBidResponse(bidRequest: BidRequest):BidResponse = {
    //to change the number of seats just change the input in the generateSeatBids function
    return new BidResponse("ID1234", bidRequest.id,generateSeatBids(5,bidRequest.imp) )
  }

  //This function generates Seat Bids
  //Gets the number of seats to generate and an impression sequence returns a SeatBid object
  private def generateSeatBids(numOfSeats:Int, impSeq:Seq[Impression]):Seq[SeatBid] = {

    //empty placeholder for the return statement
    val seatBidArr = new Array[SeatBid](numOfSeats)

    //In this loop the seatBid objects are generated and inserted to an array
    //The number of iterations is received as an argument: numOfSeats
    for( index <- 0 to numOfSeats-1){

      val seatBid = new SeatBid(generateBids(impSeq), "seatNum" + index)
      seatBidArr(index) = seatBid
    }

    //The array is transformed into a sequence and returned
    return seatBidArr.toSeq
  }

  //This function generates Bids
  //Gets a Impression object sequence and generates a Bid object for each impression in the sequence
  //The Bids are inserted in an array then returned as a sequence
  private def generateBids(impSeq:Seq[Impression]) : Seq[Bid] = {

    //empty placeholder for the return statement
    val bidArray = new Array[Bid](impSeq.size)
    //helper to insert the bids in the array
    var index = 0

    //for each impression, generate a bid object and insert it to array
    impSeq.foreach( impression => {
      val s = scala.util.Random.nextFloat()
      val bid = new Bid("https://cdn.dribbble.com/users/891859/screenshots/3472550/hireme.gif","bid"+index, impression.id, impression.bidfloor+s)
      bidArray(index) =  bid
      index+=1
    })

    //The array is transformed into a sequence and returned
    return bidArray.toSeq
  }

  /*
  * The logic of the actor messages is here*/
  def receive = {

    //Receive the bid request object, print details, create bid response, send to publisher
    case ReceiveBidRequest(bidRequestObj) => {
      println(self.path.name + " received from "+sender().path.name+" the id: " + bidRequestObj.id)
      println(self.path.name + " received from "+sender().path.name+" the user agent: " + bidRequestObj.device.ua)
      val bidResponseObj =  createBidResponse(bidRequestObj)

      sender() ! ReceiveBidResponse(bidResponseObj)
    }

    //Receive win notice for a bid
    case ReceiveWinningNotice(winNote) => {
      //initiate variables
      val imp = winNote._1
      val seatId = winNote._2._1
      val bid = winNote._2._2

      //print winning bid
      printWinner(self.path.name,imp.id,seatId,bid)

      //send the ad markup to the publisher
      sender() ! ReceiveAdMarkup(bid.adm,imp.id)
    }

  }

  //This function prints the winning bids in a nice format
  private def printWinner(actorName: String, impID: String, seatId:String, bid:Bid ):Unit = {
    println("I am %s and the winner for Impression: %s is: \n The bidder seats at seat: %s \n The bid id is %s and the settled price is: %2.4f USD".format(actorName,impID,seatId,bid.id,bid.price))
  }
}



