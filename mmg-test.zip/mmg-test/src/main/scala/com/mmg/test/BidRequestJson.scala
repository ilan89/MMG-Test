package com.mmg.test

import spray.json._
/*
* BidRequestJson contains all the logic for converting a BidRequestJSON
* to a BidRequestObject and the other way around
* */


object BidRequestJson {
//First we declare case classes object for the inner objects in the bid request
  case class Impression(banner: Banner,
                        bidfloor: Float,
                        id: String)

  case class Banner(api: Seq[Int],
                    battr: Seq[Int],
                    h: Int,
                    w: Int)

  case class App(bundle: String,
                 cat: Seq[String],
                 id: String,
                 name: String,
                 publisher: Publisher)

  case class Publisher(id: String)

  case class Device(carrier: String,
                    connectiontype: Int,
                    devicetype: Int,
                    didmd5: String,
                    didsha1: String,
                    dnt: Int,
                    dpidmd5: String,
                    dpidsha1: String,
                    geo: Geo,
                    ifa: String,
                    ip: String,
                    os: String,
                    osv: String,
                    ua: String)

  case class Geo(city: String,
                 country: String,
                 `type`: Int)

  case class User(id: String)

  //Then we declare the top-level object BidRequest
  case class BidRequest(app: App,
                        at: Int,
                        bcat: Seq[String],
                        cur: Seq[String],
                        device: Device,
                        id: String,
                        imp: Seq[Impression],
                        tmax: Int,
                        user: User)

  //Last we create implicit formats for the transformation JSON <==> OBJECT
  //One for every object we created
  object BidRequestJsonProtocol extends DefaultJsonProtocol {
    implicit val userFormat = jsonFormat1(User)
    implicit val geoFormat = jsonFormat3(Geo)
    implicit val deviceFormat = jsonFormat14(Device)
    implicit val publisherFormat = jsonFormat1(Publisher)
    implicit val appFormat = jsonFormat5(App)
    implicit val bannerFormat = jsonFormat4(Banner)
    implicit val impressionFormat = jsonFormat3(Impression)
    implicit val bidRequestFormat = jsonFormat9(BidRequest)
  }
}
