package com.mmg.test

import spray.json._

/*
* BidResponseJson contains all the logic for converting a BidResponseJSON
* to a BidResponseObject and the other way around
* */
object BidResponseJson {
  //First we declare case classes object for the inner objects in the bid response
  case class Bid(adm:String,
                 id:String,
                 impid:String,
                 price:Float)

  case class SeatBid(bid:Seq[Bid],
                     seat:String)

  //Then we declare the top-level object BidResponse
  case class BidResponse(bidID:String,
                         id:String,
                         seatBid:Seq[SeatBid])

  //Last we create implicit formats for the transformation JSON <==> OBJECT
  //One for every object we created
  object BidResponseJsonProtocol extends DefaultJsonProtocol {
    implicit val bidFormat = jsonFormat4(Bid)
    implicit val seatBidFormat = jsonFormat2(SeatBid)
    implicit val bidResponseFormat = jsonFormat3(BidResponse)
  }
}
