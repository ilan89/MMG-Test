package com.mmg.test
//import statements
import akka.actor.{ActorRef, ActorSystem, Props}
import PublisherActor._
import com.mmg.test.BidRequestJson._


object Main extends scala.App {
  //This is the name of the file to generate the bid request
  //The schema of the file must stay the same, if needed is possible to add more impressions
  val fileName = "BidRequest.json"

  //Create System
  val system: ActorSystem = ActorSystem("exchange")

  //Create actors publisher and advertiser
  val advertiserActor: ActorRef = system.actorOf(Props[AdvertiserActor],"advertiserActor")
  val publisherActor: ActorRef = system.actorOf(PublisherActor.props("", Seq.empty[Impression],advertiserActor),"publisherActor")

  //Start RTB cycle
  publisherActor ! CreateAndSendBidRequest(fileName)

  //Give time to the actors to act
  Thread.sleep(10000)

  //terminate the system
  system.terminate()
}
